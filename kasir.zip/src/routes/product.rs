// nanti tambahkan ini
    // add route GET    /products       {middleware : JWT}
    // add route GET    /products/:id   {middleware : JWT}
    // add route POST   /products       {middleware : JWT}
    // add route PUT    /products/:id   {middleware : JWT}
    // add route DELETE /products/:id   {middleware : JWT}