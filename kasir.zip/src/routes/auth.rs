// nanti tambahkan ini
    // add route POST   /login
    // add route POST   /register
    // add route POST   /logout         {middleware : JWT}
    // add route GET    /me             {middleware : JWT}
    // add route PUT    /me             {middleware : JWT}